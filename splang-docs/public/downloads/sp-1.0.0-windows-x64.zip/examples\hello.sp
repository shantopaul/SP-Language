import std.io;

fn main() -> void {
    println("Welcome to SP Programming Language 1.0!");
    println("Native LLVM compilation verified.");
}
